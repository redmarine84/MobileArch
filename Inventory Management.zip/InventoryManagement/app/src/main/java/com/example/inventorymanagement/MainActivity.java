package com.example.inventorymanagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private String[] PERMISSIONS;

    private EditText editEmail, editPassword;

    private FirebaseAuth mAuth;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PERMISSIONS = new String[]{
                Manifest.permission.SEND_SMS
        };

        Button register = (Button) findViewById(R.id.btnSignup);
        register.setOnClickListener(this);

        Button forgot = (Button) findViewById(R.id.forgot);
        forgot.setOnClickListener(this);

        Button signIn = (Button) findViewById(R.id.login);
        signIn.setOnClickListener(this);

        editEmail = (EditText) findViewById(R.id.username);
        editPassword = (EditText) findViewById(R.id.password);

        progressBar = (ProgressBar) findViewById(R.id.loading);

        mAuth = FirebaseAuth.getInstance();

    }

    private boolean hasPermissions(Context context, String...PERMISSIONS){
        if(context != null && PERMISSIONS != null){
            for(String permission: PERMISSIONS){
                if(ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED){
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 1){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "SMS Permission is Granted", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this, "SMS Permission is Denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnSignup:
                startActivity(new Intent(this, RegisterUser.class));
                break;
            case R.id.login:
                if(!hasPermissions(MainActivity.this, PERMISSIONS)){
                    ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS, 1);
                }
                userLogin();
                break;
            case R.id.forgot:
                startActivity(new Intent(this, ForgotPassword.class));
                break;

        }
    }


    private void userLogin() {

        String email = editEmail.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if(email.isEmpty()){
            editEmail.setError("Email is required!");
            editEmail.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editEmail.setError("Enter a valid Email!");
            editEmail.requestFocus();
            return;
        }

        if(password.isEmpty()){
            editPassword.setError("Password is required!");
            editPassword.requestFocus();
            return;
        }

        if(password.length() < 6){
            editPassword.setError("Min password length is 6 characters!");
            editPassword.requestFocus();
            return;
        }


        progressBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                assert user != null;
                if(user.isEmailVerified()){
                    startActivity(new Intent(MainActivity.this, Inventory.class));
                    progressBar.setVisibility(View.GONE);
                }else{
                    user.sendEmailVerification();
                    Toast.makeText(MainActivity.this, "Check you Email Inbox/Spam to verify your account", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }
            }else{
                Toast.makeText(MainActivity.this, "Failed to login! Please check Email and Password", Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.GONE);
            }
        });
    }
}