package com.example.inventorymanagement;

public class User {

    public String firstName, lastName, email, phone;

    public User(){

    }
    public User(String firstName, String lastName, String email, String phone){
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;

    }
}
