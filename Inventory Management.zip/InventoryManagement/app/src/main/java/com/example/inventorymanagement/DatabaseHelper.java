package com.example.inventorymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String INVENTORY_TABLE = "INVENTORY_TABLE";
    public static final String COLUMN_INVENTORY_NAME = "INVENTORY_NAME";
    public static final String COLUMN_INVENTORY_QUANTITY = "INVENTORY_QUANTITY";
    public static final String COLUMN_INVENTORY_LOCATION = "INVENTORY_LOCATION";
    public static final String COLUMN_ID = "ID";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "stock.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + INVENTORY_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_INVENTORY_NAME + " TEXT, " + COLUMN_INVENTORY_QUANTITY + " INT, " + COLUMN_INVENTORY_LOCATION + " TEXT)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean addOne(String name,String quantity,String location){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_INVENTORY_NAME, name);
        cv.put(COLUMN_INVENTORY_QUANTITY, quantity);
        cv.put(COLUMN_INVENTORY_LOCATION, location);

        long insert = db.insert(INVENTORY_TABLE, null, cv);
        if(insert == -1){
            return false;
        }else{
            return true;
        }
    }

    public boolean updateOne(String id,String name,String quantity,String location){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ID, id);
        cv.put(COLUMN_INVENTORY_NAME, name);
        cv.put(COLUMN_INVENTORY_QUANTITY, quantity);
        cv.put(COLUMN_INVENTORY_LOCATION, location);

        db.update(INVENTORY_TABLE, cv, "ID = ?", new String[]{id});
        return true;
    }

    public int deleteOne(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        //String queryString = "DELETE FROM " + INVENTORY_TABLE + " WHERE " + COLUMN_ID + " = " + stock.getId();

        //Cursor cursor = db.rawQuery(queryString, null);

        //if(cursor.moveToFirst()){
        //    return true;
        //}else{
        //    return false;
        //}
        return db.delete(INVENTORY_TABLE, "ID = ?",new String[] {id});

    }

    public List<Stock> getAllInventoryStock(){
        List<Stock> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " +  INVENTORY_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            //loop through the cursor result set
            do{
                int prodID = cursor.getInt(0);
                String prodName = cursor.getString(1);
                int prodQty = cursor.getInt(2);
                String prodLoc = cursor.getString(3);

                Stock newStock = new Stock(prodID, prodName, prodQty, prodLoc);
                returnList.add(newStock);

            }while(cursor.moveToNext());

        }
        else{
            //Failure. Do not add anything to the list
        }
        // Close both the db and cursor when done
        cursor.close();
        db.close();
        return returnList;
    }
}
