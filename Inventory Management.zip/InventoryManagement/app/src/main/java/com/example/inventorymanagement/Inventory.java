package com.example.inventorymanagement;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.List;

public class Inventory extends AppCompatActivity implements View.OnClickListener {

    private EditText edit1;
    private EditText edit2;
    private EditText edit3;
    private EditText edit4;
    private EditText phone;

    Button btnAddData;
    Button btnDelete;
    Button btnViewUpdate;

    private ListView stockList;
    ArrayAdapter allInventoryAdapter;
    DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        edit1 = findViewById(R.id.edit1);
        edit2 = findViewById(R.id.edit2);
        edit3 = findViewById(R.id.edit3);
        edit4 = findViewById(R.id.edit4);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("Low Inventory", "Low Inventory", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationChannel channel2 = new NotificationChannel("Inventory Depleted", "Inventory Depleted", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
            manager.createNotificationChannel(channel2);
        }

        stockList = findViewById(R.id.viewAllInventory);

        addData();
        updateData();
        deleteData();
        updateList();

    }
    private void lowInventory(){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(Inventory.this, "Low Inventory");
        builder.setContentTitle("Low Inventory");
        builder.setContentText("Inventory Low! Please Restock!");
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setAutoCancel(true);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(Inventory.this);
        managerCompat.notify(1, builder.build());

    }

    private void inventoryDepleted(){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(Inventory.this, "Inventory Depleted");
        builder.setContentTitle("Inventory Depleted");
        builder.setContentText("Inventory Empty! Please Restock!");
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setAutoCancel(true);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(Inventory.this);
        managerCompat.notify(1, builder.build());

    }

    private void updateList() {
        databaseHelper = new DatabaseHelper(Inventory.this);
        List<Stock> allStock = databaseHelper.getAllInventoryStock();

        allInventoryAdapter = new ArrayAdapter<Stock>(Inventory.this, android.R.layout.simple_list_item_1, allStock);
        stockList.setAdapter(allInventoryAdapter);
        int stock = allStock.size();
        int stocks = stock - 1;
        if(stocks == 2){
            lowInventory();
        }else if(stocks < 0){
            inventoryDepleted();
        }
        return;
    }

    public void addData(){
        btnAddData = findViewById(R.id.addButton);
        btnAddData.setOnClickListener(view -> {
            boolean isInserted;
            isInserted = databaseHelper.addOne(edit1.getText().toString(),
                    edit2.getText().toString(),
                    edit3.getText().toString() );
            if(isInserted) {
                Toast.makeText(Inventory.this, "Data Inserted", Toast.LENGTH_LONG).show();
            }else {
                Toast.makeText(Inventory.this, "Data not Inserted", Toast.LENGTH_LONG).show();
            }
            updateList();
        });

    }

    public void updateData() {
        btnViewUpdate = findViewById(R.id.updateButton);
        btnViewUpdate.setOnClickListener(view -> {
            boolean isUpdate = databaseHelper.updateOne(edit4.getText().toString(),
                    edit1.getText().toString(),
                    edit2.getText().toString(),edit3.getText().toString());
            if(isUpdate) {
                Toast.makeText(Inventory.this, "Data Update", Toast.LENGTH_LONG).show();
            }else {
                Toast.makeText(Inventory.this, "Data Not Updated", Toast.LENGTH_LONG).show();
            }
            updateList();

        });
    }

    public void deleteData(){
        btnDelete = findViewById(R.id.deleteButton);
        btnDelete.setOnClickListener(view -> {
            Integer deletedRows = databaseHelper.deleteOne(edit4.getText().toString());
            if(deletedRows > 0){
                Toast.makeText(Inventory.this, "Data Deleted", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(Inventory.this, "Data Not Deleted", Toast.LENGTH_LONG).show();
            }
            updateList();

        });
    }

    @Override
    public void onClick(View view) {

    }
}
