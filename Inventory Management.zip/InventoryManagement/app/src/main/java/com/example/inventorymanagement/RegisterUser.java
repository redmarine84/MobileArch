package com.example.inventorymanagement;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener {

    private EditText edit1, edit2, edit3, edit4, edit5;
    private Button btn1;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        mAuth = FirebaseAuth.getInstance();

        btn1 = (Button) findViewById(R.id.button);
        btn1.setOnClickListener(this);

        edit1 = (EditText) findViewById(R.id.editTextFirstName);
        edit2 = (EditText) findViewById(R.id.editTextLastName);
        edit3 = (EditText) findViewById(R.id.editTextEmailAddress);
        edit4 = (EditText) findViewById(R.id.editTextPassword);
        edit5 = (EditText) findViewById(R.id.editTextPhoneNumber);

        progressBar = (ProgressBar) findViewById(R.id.loading);

    }
    public void User(){

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.button:
                registerUser();
                startActivity(new Intent(this, MainActivity.class));
                break;
        }
    }

    private void registerUser(){
        String firstName = edit1.getText().toString().trim();
        String lastName = edit2.getText().toString().trim();
        String email= edit3.getText().toString().trim();
        String password = edit4.getText() .toString().trim();
        String phone = edit5.getText().toString().trim();

        if(firstName.isEmpty()){
            edit1.setError("First name is required!");
            edit1.requestFocus();
            return;
        }
        if(lastName.isEmpty()){
            edit2.setError("Last name is required!");
            edit2.requestFocus();
            return;
        }
        if(email.isEmpty()) {
            edit3.setError("Email is required!");
            edit3.requestFocus();
            return;
        }
        if(phone.isEmpty()){
            edit5.setError("Phone Number is required!");
            edit5.requestFocus();
            return;
        }
        if(!Patterns.PHONE.matcher(phone).matches()){
            edit5.setError("Please provide a valid Phone Number!");
            edit5.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            edit3.setError("Please provide a valid Email!");
            edit3.requestFocus();
            return;
        }
        if(password.isEmpty()){
            edit4.setError("Password is required!");
            edit4.requestFocus();
            return;
        }
        if(password.length() < 6){
            edit4.setError("Min password length should be 6 characters!");
            edit4.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful()){
                        User user = new User(firstName, lastName, email, phone);

                        FirebaseDatabase.getInstance().getReference("Users")
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .setValue(user).addOnCompleteListener(task1 -> {
                                    if(task1.isSuccessful()){
                                        Toast.makeText(RegisterUser.this, "User has been registered successfully!",Toast.LENGTH_LONG).show();
                                        // redirect to login layout
                                    }else{
                                        Toast.makeText(RegisterUser.this, "Failed to register User! Try Again!", Toast.LENGTH_LONG).show();
                                    }
                                    progressBar.setVisibility(View.GONE);
                                });
                    }else{
                        Toast.makeText(RegisterUser.this, "Failed to register User! Try Again!", Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }
}